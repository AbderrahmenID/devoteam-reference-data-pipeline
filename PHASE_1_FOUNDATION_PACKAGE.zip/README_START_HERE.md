# Devoteam Reference Intelligence Platform

This folder is the clean engineering foundation for the enterprise pilot.

## Phase 1 purpose

Phase 1 creates the project structure, configuration contract, security defaults,
logging, run manifests, and automated tests. It does **not** read, copy, OCR,
index, or modify the source corpus.

## First command

Run the Colab notebook `00_PHASE_1_PROJECT_FOUNDATION.ipynb` from the root of
`Devoteam_AI_CLEAN_PIPELINE`. The notebook safely expands the foundation package,
validates all configuration files, runs the tests, and writes a run manifest.

## Engineering rule

Notebooks demonstrate and orchestrate work. Reusable logic belongs under
`src/devoteam_reference_ai/` and is covered by tests.

## Approved baseline

- Enterprise pilot: A1
- Security-gated provider-neutral LLM: B1
- Tunisia / North and West Africa initial users: C1
- Four confidentiality levels: D1
- Governance roles: E1
- Controlled pilot: F1
- Filter catalogue: G1

See `PHASE_0_PROJECT_CHARTER.md` for the approved project charter.

